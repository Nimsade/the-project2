import { snakeBody, moveSnake, food, changeFoodPos } from "./gamePlay.js";

changeFoodPos();
food();
snakeBody();
moveSnake();
